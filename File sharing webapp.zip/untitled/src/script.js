document.addEventListener("DOMContentLoaded", function () {
  const fileInput = document.getElementById("fileInput");
  const fileList = document.getElementById("fileList");
  const fileUploadForm = document.getElementById("fileUploadForm");

  // Function to load files from local storage and display them
  function loadFiles() {
    fileList.innerHTML = ""; // Clear list

    // Retrieve files from local storage
    const files = JSON.parse(localStorage.getItem("files")) || [];
    files.forEach((file, index) => {
      const listItem = document.createElement("li");
      listItem.innerHTML = `
        ${file.name}
        <button onclick="downloadFile(${index})">Download</button>
        <button onclick="deleteFile(${index})">Delete</button>
      `;
      fileList.appendChild(listItem);
    });
  }

  // Handle form submission to upload files
  fileUploadForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const file = fileInput.files[0];

    if (file) {
      // Convert file to base64
      const reader = new FileReader();
      reader.onload = function () {
        const files = JSON.parse(localStorage.getItem("files")) || [];
        files.push({ name: file.name, data: reader.result });
        localStorage.setItem("files", JSON.stringify(files));
        loadFiles();
        fileInput.value = ""; // Reset file input
      };
      reader.readAsDataURL(file);
    }
  });

  // Function to download a file
  window.downloadFile = function (index) {
    const files = JSON.parse(localStorage.getItem("files")) || [];
    const file = files[index];

    // Create a temporary anchor element to trigger download
    const a = document.createElement("a");
    a.href = file.data;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  // Function to delete a file
  window.deleteFile = function (index) {
    const files = JSON.parse(localStorage.getItem("files")) || [];
    files.splice(index, 1);
    localStorage.setItem("files", JSON.stringify(files));
    loadFiles();
  };

  // Load files on page load
  loadFiles();
});
